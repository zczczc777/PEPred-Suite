氨基酸组成（AAC）编码（Bhasin和Raghava，2004）
Bhasin, M. and Raghava, G.P. (2004) Classification of nuclear receptors based on amino acid composition and dipeptide composition. J Biol Chem, 279, 23262-23266.
使用以下命令提取AAC功能描述符：
python Fea.py --file examples/test-protein.txt  --type AAC --out outFile


氨基酸成分切割（AAC_CUT）特征类型。
它根据固定长度的序列窗口（默认值为5）计算AAC,可以从每个肽的N-末F端连续滑动到C-末端，或者从每个肽的c-末端连续滑动到N-末端，并且通常可以应用于编码
长度相等的肽。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt  --type AAC --CutLength NT5 --out outFile
python Fea.py --file examples/test-protein.txt  --type AAC --CutLength CT5  --out outFile
python Fea.py --file examples/test-protein.txt  --type AAC --CutLength NTCT5  --out outFile


分组氨基酸组成（GAAC）
在GAAC编码中，20种氨基酸类型进一步分为五类它们的物理化学性质，例如， 疏水性，电荷和分子大小（Lee，et al。，
2011B）。 五类包括脂肪族基团（g1：GAVLMI），芳香族基团（g2：FYW），正电荷基团（g3：KRH），负电荷基团（g4：DE）和不带电基团（g5：
STCPNQ）。使用以下命令提取GAAC功能描述符：
python Fea.py --file examples/test-protein.txt --type GAAC --out outFile


氨基酸成分切割（GAAC_CUT）特征类型。
它根据固定长度的序列窗口（默认值为5）计算GAAC,可以从每个肽的N-末端连续滑动到C-末端，或者从每个肽的c-末端连续滑动到N-末端，并且通常可以应用于编码
长度相等的肽。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt  --type GAAC --CutLength NT5 --out outFile
python Fea.py --file examples/test-protein.txt  --type GAAC --CutLength CT5  --out outFile
python Fea.py --file examples/test-protein.txt  --type GAAC --CutLength NTCT5  --out outFile


k-间隔氨基酸对（KGAAC）的组成
k-间隔氨基酸组对（K_GAAC）的组成是CKSAAP的变体描述符。 它计算氨基酸对的频率由任何k个残基分隔（k的默认最大值设置为5）。 以k = 0为例，有25个0-间隔的组对（即g1g1，g1g2，g1g3，... g5g5）。 
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type KGAAC --out outFile


间隔氨基酸对（KGAAC_CUT）的组成
k-间隔氨基酸组对（K_GAAC）的组成是CKSAAP的变体描述符。 它计算氨基酸对的频率由任何k个残基分隔（k的默认最大值设置为5）。 以k = 0为例，有25个0-间隔的组对（即g1g1，g1g2，g1g3，... g5g5）。 
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type KGAAC  --CutLength NT5 --out outFile
python Fea.py --file examples/test-protein.txt --type KGAAC  --CutLength CT5 --out outFile
python Fea.py --file examples/test-protein.txt --type KGAAC  --CutLength NTCT5 --out outFile


二肽组合物（DPC）（Saravanan和Gautham，2015）给出了400个描述符。
Saravanan, V. and Gautham, N. (2015) Harnessing Computational Biology for Exact Linear B-Cell Epitope Prediction: A Novel Amino Acid Composition-Based Feature Descriptor. OMICS, 19, 648-658.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type DPC --out outFile

分组二肽组合物（GDPC）
分组二肽组成编码是DPC描述符的另一种变体。 它是由总共25个描述符组成，定义为：
使用以下命令提功能描述符：
python Fea.py --file examples/test-protein.txt --type GDPC  --out outFile


k-间隔氨基酸对（KGDPC）的组成
k-间隔氨基酸组对（KGDPC）的组成是CKSAAP的变体描述符它计算氨基酸对的频率由任何k个残基分隔（k的默认最大值设置为5）。 以k = 0为例，有25个0-间隔的组对（即g1g1，g1g2，g1g3，... g5g5）。
使用以下命令提功能描述符：
python Fea.py --file examples/test-protein.txt --type KGDPC  --out outFile

 
在一级结构相距g个间隔的两个氨基酸残基，在三级结构空间可能是相邻的，电子科大林昊老师提出的g-gap二肽组成(GGAP)。
以序列"ACDEA"为例，gap=0时的二肽组成有AC,CD,DE,EA, gap=1时的二肽组成有AD,CE,DA
Chen, et al., 2009; Chen, et al., 2007a; Chen, et al., 2007b; Chen, et al., 2008
使用以下命令提功能描述符：
python Fea.py --file examples/test-protein.txt --type GGAP --GAP 5 --out outFile


自适应跳跃二肽组合物（ASDC）。 我们最近提出了一种改进的二肽组合物，称为自适应跳跃二肽组合物（Wei，et al。，2017; Wei，et al。，2017）。 该描述符充分考虑了不仅存在于之间的相关信息相邻残基，但也介于中间残基之间。
Chen, et al., 2009; Chen, et al., 2007a; Chen, et al., 2007b; Chen, et al., 2008
使用以下命令提功能描述符：
python Fea.py --file examples/test-protein.txt --type ASDC --out outFile


二肽偏离预期平均值（DDE）
二肽与预期平均特征向量的偏差（Saravanan和Gautham，2015）是通过计算三个参数构建，即二肽组成（Dc），理论平均值（Tm），和理论方差（Tv）。 
Saravanan, V. and Gautham, N. (2015) Harnessing Computational Biology for Exact Linear B-Cell Epitope Prediction: A Novel Amino Acid Composition-Based Feature Descriptor. OMICS, 19, 648-658.
使用以下命令提功能描述符：
python Fea.py --file examples/test-protein.txt --type DDE --out outFile

三肽组合物（TPC）（Bhasin和Raghava，2004）给出了8000个描述符
Bhasin, M. and Raghava, G.P. (2004) Classification of nuclear receptors based on amino acid composition
and dipeptide composition. J Biol Chem, 279, 23262-23266.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type TPC --out outFile


分组三肽组合物组成（GTPC）
在GTPC编码中，20种氨基酸类型进一步分为五类它们的物理化学性质，例如， 疏水性，电荷和分子大小（Lee，et al。，
2011B）。 五类包括脂肪族基团（g1：GAVLMI），芳香族基团（g2：FYW），正电荷基团（g3：KRH），负电荷基团（g4：DE）和不带电基团（g5：STCPNQ）。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type GTPC --out outFile

CTDC
以疏水性属性为例，所有氨基酸分为三组：极性，中性和疏水性（表S1）。使用以下命令提取CTDC功能描述符：
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type CTDC --out outFile

CTDT
转换描述符T也由三个值组成（Dubchak，et al。，1995; Dubchak，et al。，1999）
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type CTDT --out outFile

CTDD
分布描述符由三个组中的每一个组成的五个值（极性，中性和疏水的（Dubchak，et al。，1995; Dubchak，et al。，1999），即相应的部分整个序列，其中给定组的第一个残基位于，其中25,50,75和
100％的事件被包含在内。
Dubchak, I., et al. (1995) Prediction of protein folding class using global description of amino acid sequence.
Proc Natl Acad Sci U S A, 92, 8700-8704.
Dubchak, I., et al. (1999) Recognition of a protein fold in the context of the Structural Classification of
Proteins (SCOP) classification. Proteins, 35, 401-407. 
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type CTDD --out outFile



Moran correlation (Moran)
相关描述符是基于氨基酸性质的分布来定义的序列（Feng和Zhang，2000; Horne，1988; Sokal和Thomson，2006）。氨基酸这里使用的属性是不同类型的氨基酸指数，从AAindex中检索
数据库（Kawashima，et al。，2008），可在http://www.genome.jp/dbget/aaindex.html/获得。
Feng, Z.P. and Zhang, C.T. (2000) Prediction of membrane protein types based on the hydrophobic index of amino acids. J Protein Chem, 19, 269-275.
Horne, D.S. (1988) Prediction of protein helix content from an autocorrelation analysis of sequence hydrophobicities. Biopolymers, 27, 451-477.
okal, R.R. and Thomson, B.A. (2006) Population structure inferred by local spatial autocorrelation: an example from an Amerindian tribal population. Am J Phys Anthropol, 129, 121-131.
Kawashima, S., et al. (2008) AAindex: amino acid index database, progress report 2008. Nucleic Acids Res,36, D202-205.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type Moran --out outFile


Geary相关（Geary）
Geary自相关描述符（Sokal和Thomson，2006），用于蛋白质或肽序列
Sokal, R.R. and Thomson, B.A. (2006) Population structure inferred by local spatial autocorrelation: an example from an Amerindian tribal population. Am J Phys Anthropol, 129, 121-131.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt  --type Geary --out outFile



归一化Moreau-Broto自相关（NMBroto）
Moreau-Broto自相关描述符（Horne，1988）
Horne, D.S. (1988) Prediction of protein helix content from an autocorrelation analysis of sequence hydrophobicities. Biopolymers, 27, 451-477.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type NMBroto --out outFile


Conjoint Triad（CTriad）
Conjoint Triad描述符（CTriad）考虑了一种氨基酸及其邻位的特性通过将任何三个连续氨基酸视为单个单元来确定氨基酸（Shen，et al。，2007）。第一，蛋白质序列由二元空间（V，F）表示，其中V表示向量空间序列特征，每个特征（Vi）代表一种三元组类型; F是数字向量
对应于V，其中fi，即F的第i维的值，是出现的类型Vi的数量在蛋白质序列中。
Shen, J., et al. (2007) Predicting protein-protein interactions based only on sequences information. Proc Natl Acad Sci U S A, 104, 4337-4341.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type CTriad --out outFile



k-Spaced Conjoint Triad（KSCTriad）
k-Spaced Conjoint Triad（KSCTriad）描述符基于Conjoint CTriad描述符，它不仅可以计算三个连续氨基酸单元的数量，还可以考虑由任何k个残基分开的连续氨基酸单元（k的默认最大值
设置为5）。例如，AxRxT是1个间隔的三元组。因此，KSCTriad的维度编码特征向量是343（k + 1）。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type KSCTriad --out outFile

序列 - 耦合数（SOCNumber）
第d级序列顺序耦合数定义为：
其中di，i + d是描述两个氨基酸之间距离的给定距离矩阵中的条目在位置i和i+d处，nlag表示滞后的最大值（默认值：30），N是蛋白质或肽序列的长度。作为距离矩阵的Schneider-Wrede
物理化学距离矩阵（Schneider和Wrede，1994）由Kuo-Chen Chou和使用Grantham（Grantham，1974）的化学距离矩阵。
Schneider, G. and Wrede, P. (1994) The rational design of amino acid sequences by artificial neural networks and simulated molecular evolution: de novo design of an idealized leader peptidase cleavage site. Biophys J, 66, 335-344.
Grantham, R. (1974) Amino acid difference formula to help explain protein evolution. Science, 185, 862-864.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type SOCNumber --out outFile


准序列次序（QSOrder）
对于每种氨基酸类型，准序列顺序描述符可以定义为:其中fr是氨基酸类型r的标准化出现，w是加权因子（w = 0.1）
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type QSOrder --out outFile



假氨基酸组成（PAAC）
这组描述符已在（Chou，2001; Chou，2005）中提出。
Chou, K.C. (2001) Prediction of protein cellular attributes using pseudo-amino acid composition. Proteins,
43, 246-255.
Chou, K.C. (2005) Using amphiphilic pseudo amino acid composition to predict enzyme subfamily classes.
Bioinformatics, 21, 10-19.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type PAAC 


两亲性假氨基酸组合物（APAAC）
在（Chou，2001; Chou，2005）中提出了两亲性假氨基酸组合物（APAAC）。
Chou, K.C. (2001) Prediction of protein cellular attributes using pseudo-amino acid composition. Proteins,
43, 246-255.
Chou, K.C. (2005) Using amphiphilic pseudo amino acid composition to predict enzyme subfamily classes.
Bioinformatics, 21, 10-19.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type APAAC --out outFile


肽的K-最近邻（KNNpeptide）
肽的K-最近邻（KNNpeptide）描述符（Chen，et al。，2013a）需要额外的培训文件和标签文件。
Chen, X., et al. (2013a) Incorporating key position and amino acid residue features to identify general and
species-specific Ubiquitin conjugation sites. Bioinformatics, 29, 1614-1622.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type KNNpeptide --train examples/train-peptide.txt --label examples/label.txt 


K-蛋白质最近邻（KNNprotein）
蛋白质的K-最近邻（KNNProtein）描述符类似于KNNpeptide描述。这两个描述符之间的唯一区别是计算相似性的方式。在
KNN蛋白通过应用NeedlemanWunsch算法（Needleman和Wunsch，1970）获得两个蛋白质序列的相似性得分。
Needleman, S.B. and Wunsch, C.D. (1970) A general method applicable to the search for similarities in the
amino acid sequence of two proteins. J Mol Biol, 48, 443-453.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type KNNprotein --train examples/train-protein.txt --label examples/label.txt


PSSM profile (PSSM)
该特征描述符（Cai，et al。，2012; Radivojac，et al。，2010）是从位置特定评分矩阵（PSSM）简档中提取的。
Cai, Y., et al. (2012) Prediction of lysine ubiquitination with mRMR feature selection and analysis. Amino
Acids, 42, 1387-1395.
Radivojac, P., et al. (2010) Identification, analysis, and prediction of protein ubiquitination sites. Proteins,
78, 365-380.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type PSSM --path examples/predictedProteinProperty


AAindex（AAINDEX）
氨基酸的物理化学性质是最直观的表征特征生化反应已广泛应用于生物信息学研究。氨基酸指数（AAindex）数据库（Kawashima，et al。，2008）收集了许多已发表的指数氨基酸的理化性质。对于每种物理化学性质，有一组20所有氨基酸的数值。
Kawashima, S., et al. (2008) AAindex: amino acid index database, progress report 2008. Nucleic Acids Res, 36, D202-205.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type AAINDEX --out outFile


二级结构元素含量（SSEC）
蛋白质二级结构首先由PSIPRED V4.0软件预测（Jones，1999）。
Jones, D.T. (1999) Protein secondary structure prediction based on position-specific scoring matrices. J Mol Biol, 292, 195-202.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type SSEC --path examples/predictProteinProperty/
'--path'指定预测的蛋白质二级结构文件的路径，以及预测的二级结构文件可以通过运行脚本“generateSecondaryStructure.py”获得脚本目录。


二级结构元素二进制（SSEB）
在二级结构元素二元（SSEB）描述符中，肽中的每个残基是由三维矢量表示，即Helix（001），Strand（010），Coil（100）。 SSEB描述符可用于编码相等长度的肽。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type SSEB --CutLength NT5  --path  examples/predictProteinProperty  --out outFile
python Fea.py --file examples/test-peptide.txt --type SSEB --CutLength CT5  --path  examples/predictProteinProperty  --out outFile
python Fea.py --file examples/test-peptide.txt --type SSEB --CutLength NTCT5  --path  examples/predictProteinProperty  --out outFile


可访问的溶剂可访问性（ASA）
SPINE-X首先预测了蛋白质可访问溶剂可及性信息软件（Faraggi，et al。，2009; Heffernan，et al。，2016; Heffernan，et al。，2015）。预测的ASAvalue用作输入要素。ASA描述符可用于编码具有相同的肽长度。
Heffernan, R., et al. (2016) Highly accurate sequence-based prediction of half-sphere exposures of amino
acid residues in proteins. Bioinformatics, 32, 843-849.
Heffernan, R., et al. (2015) Improving prediction of secondary structure, local backbone angles, and solvent
accessible surface area of proteins by iterative deep learning. Sci Rep, 5, 11476.
Faraggi, E., et al. (2009) Predicting continuous local structure and the effect of its substitution for secondary
structure in fragment-free protein structure prediction. Structure, 17, 1515-1527.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type ASA  --CutLength NT5  --path examples/predictProteinProperty --out outFile
python Fea.py --file examples/test-peptide.txt --type ASA  --CutLength CT5  --path examples/predictProteinProperty --out outFile
python Fea.py --file examples/test-peptide.txt --type ASA  --CutLength NTCT5  --path examples/predictProteinProperty --out outFile
'--path'指定SPINE-X输出文件的路径。


Disorder（Disorder）
蛋白质病症信息首先由VSL2软件预测（Obradovic等，2005; Peng，等人，2006）。将预测的概率值作为特征。 Disorder描述符（Cai，et
al。，2012; Chen等人，2015）可用于编码相等长度的肽。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type Disorder --CutLength NT5 --path examples/predictProteinProperty
python Fea.py --file examples/test-peptide.txt --type Disorder --CutLength CT5 --path examples/predictProteinProperty
python Fea.py --file examples/test-peptide.txt --type Disorder --CutLength NTCT5 --path examples/predictProteinProperty
'--path'指定预测的蛋白质病症文件的路径。

DisorderC（DisorderC）
对于该描述符，计算无序和顺序的内容。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-protein.txt --type DisorderC --CutLength NT5 --path examples/predictProteinProperty
python Fea.py --file examples/test-protein.txt --type DisorderC --CutLength CT5 --path examples/predictProteinProperty
python Fea.py --file examples/test-protein.txt --type DisorderC --CutLength NTCT5 --path examples/predictProteinProperty

DisorderB（DisorderB）
对于Disorder Binary（DisorderB）描述符，表示肽序列中的每个残基通过二维载体，即（10）的有序残基和（01）的无序残基。该DisorderB描述符可用于编码相等长度的肽。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type DisorderB --CutLength NT5 --path examples/predictProteinProperty
python Fea.py --file examples/test-peptide.txt --type DisorderB --CutLength CT5 --path examples/predictProteinProperty
python Fea.py --file examples/test-peptide.txt --type DisorderB --CutLength NTCT5 --path examples/predictProteinProperty


Torsion angle （TA）
蛋白质Torsion Angle信息也首先由SPINE-X软件（Faraggi，等，2009; Heffernan等，2016; Heffernan等，2015）。预测的“phi”和“psi”值用作功能。 TA描述符可用于编码相等长度的肽。
Heffernan, R., et al. (2016) Highly accurate sequence-based prediction of half-sphere exposures of amino
acid residues in proteins. Bioinformatics, 32, 843-849.
Heffernan, R., et al. (2015) Improving prediction of secondary structure, local backbone angles, and solvent
accessible surface area of proteins by iterative deep learning. Sci Rep, 5, 11476.
Faraggi, E., et al. (2009) Predicting continuous local structure and the effect of its substitution for secondary
structure in fragment-free protein structure prediction. Structure, 17, 1515-1527.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type TA --CutLength NT5 --path examples/predictProteinProperty
python Fea.py --file examples/test-peptide.txt --type TA --CutLength CT5 --path examples/predictProteinProperty
python Fea.py --file examples/test-peptide.txt --type TA --CutLength NTCT5 --path examples/predictProteinProperty
'--path'指定SPINE-X输出文件的路径。



Z-Scale（ZSCALE）
对于该描述符，每个氨基酸的特征在于五个物理化学描述符变量，由Sandberg等人开发。1998年（Sandberg，etal。，1998）。该ZSCALE描述符（Chen，etal。，2012）可用于编码相等长度的肽。
Sandberg, M., et al. (1998) New chemical descriptors relevant for the design of biologically active peptides. A multivariate characterization of 87 amino acids. J Med Chem, 41, 2481-2491.
Chen, Y.Z., et al. (2012) SUMOhydro: a novel method for the prediction of sumoylation sites based on hydrophobic properties. PLoS One, 7, e39195.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type ZSCALE --CutLength NT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type ZSCALE --CutLength CT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type ZSCALE --CutLength NTCT5 --out outFile


BLOSUM62 (BLOSUM62) 
在该描述符中，BLOSUM62矩阵用于表示蛋白质一级序列信息作为基本功能集。包含m×n个元素的矩阵用于表示每个训练数据集中的残差，其中n表示肽长度，m=20，这些元素包含20个氨基酸。 BLOSUM62矩阵中的每一行用于编码20个氨基酸中的一个酸。 BLOSUM62描述符（Lee，et al。，2011a）可用于编码相同的肽长度。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type BLOSUM62 --CutLength NT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type BLOSUM62 --CutLength CT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type BLOSUM62 --CutLength NTCT5 --out outFile

Overlapping Property Features(OLP)
氨基酸被分类根据其理化性质分为以下10组（Dou，et al。，2014）。 这些包括芳香{F，Y，W，H}，负{D，E}，正{K，H，R}，极{N，Q，S，D，E，C，T，K，R，H，Y，W}，疏水性{A，G，C，T，I，V，L，K，H，F，Y，W，M}，脂肪族{I，V，L}，Tiny {A，S，G，C}，带电荷{K，H，R，D，E}，小{P，N，D，T，C，A，G，S，V}和Proline（Ferlay，等人）。
Ferlay, J., et al. Estimates of worldwide burden of cancer in 2008: GLOBOCAN 2008. International Journal of Cancer 2010;127(12):2893-2917.
Dou, Y., Yao, B. and Zhang, C. PhosphoSVM: prediction of phosphorylation sites by integrating various protein sequence attributes with a support vector machine.
Amino Acids 2014;46(6):1459-1469.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type OLP --CutLength NT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type OLP --CutLength CT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type OLP --CutLength NTCT5 --out outFile


Binary profile Features (BIT20)
标准氨基酸字母表中有20种不同的氨基酸。 每种氨基酸可以使用由0/1组成的以下特征向量进行编码。
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type BIT20 --CutLength NT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type BIT20 --CutLength CT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type BIT20 --CutLength NTCT5 --out outFile

Twenty-One-Bit Features (BIT21)
标准氨基酸字母表也可以基于以下七种物理化学性质分类：极性，标准化范德瓦尔斯体积，疏水性，二级结构，溶剂可及性，电荷和极化率（Govindan和Nair，2011）。 
Govindan, G. and Nair, A.S. Composition, Transition and Distribution (CTD)—a dynamic feature for predictions based on hierarchical structure of cellular sorting. In, 2011 Annual IEEE India Conference. IEEE; 2011. p. 1-6
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type BIT21 --CutLength NT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type BIT21 --CutLength CT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type BIT21 --CutLength NTCT5 --out outFile

Information Theory Features(IT) 
基于主序列并从多个角度充分探索序列信息，使用三个描述符变量来描述等距序列[23]。 使用该特征表示算法，分析并计算等距序列以形成三维特征向量。
Leyi Wei, PengWei Xing, Jijun Tang, and Quan Zou*. PhosPred-RF: a novel sequence-based predictor for phosphorylation sites using sequential information only. 2017. IEEE Transactions on Nanobioscience. DOI:10.1109/TNB.2017.2661756.
使用以下命令提取功能描述符：
python Fea.py --file examples/test-peptide.txt --type IT --CutLength NT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type IT --CutLength CT5 --out outFile
python Fea.py --file examples/test-peptide.txt --type IT --CutLength NTCT5 --out outFile